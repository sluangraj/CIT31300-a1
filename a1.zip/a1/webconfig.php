<?php
define('ABSOLUTE_PATH', '/home/sluangra/htdocs/CIT31300/a1');
define('URL_ROOT', 'http://corsair.cs.iupui.edu:23671/CIT31300/a1');
?>
